

function new_post() {
    document.location.href = '/bbs/create/'
}