from django.shortcuts import render
from bbs.models import Board


def b_list(request):
    # Database처리와 로직처리를 하고
    # 결과를 만들면 그 결과를 context라고 표현되는 dictionary에
    # 담아서 Template HTML file을 이용해서 HttpResponse객체를 생성한 후
    # 리턴.
    # 게시글 테이블에서 모든 게시글을 다 가져와야 해요!
    # Board class의 객체를 게시글마다 만들어서 가져와야 해요!
    posts = Board.objects.all().order_by('-id')

    context = {
        "posts": posts
    }

    return render(request, 'bbs/list.html', context)


def b_create(request):
    # 새글을 작성할 수 있는 화면을 만들어 클라이언트에게 전달.
    return render(request, 'bbs/create.html')
