from django.shortcuts import render, redirect, get_object_or_404
from bbs.models import Board
from bbs.forms import BoardForm, BoardDetailForm


def b_list(request):
    # Database처리와 로직처리를 하고
    # 결과를 만들면 그 결과를 context라고 표현되는 dictionary에
    # 담아서 Template HTML file을 이용해서 HttpResponse객체를 생성한 후
    # 리턴.
    # 게시글 테이블에서 모든 게시글을 다 가져와야 해요!
    # Board class의 객체를 게시글마다 만들어서 가져와야 해요!
    posts = Board.objects.all().order_by('-id')

    context = {
        "posts": posts
    }

    return render(request, 'bbs/list.html', context)


def b_create(request):
    # request방식이 GET인지 POST인지 구분해서 처리.
    # 만약 GET방식이면 빈 입력상자를 출력하고 POST방식이면 입력된 데이터를
    # 이용해서 Database처리.
    if request.method == 'GET':
        # 새글을 작성할 수 있는 화면을 만들어 클라이언트에게 전달.
        # 입력 양식인 ModelForm 객체를 하나 생성
        board_form = BoardForm()

        context = {
            "my_form": board_form
        }

        return render(request, 'bbs/create.html', context)
    else:
        # POST방식인 경우에는 이 부분이 수행되요!
        # 클라이언트가 입력상자에 입력한 내용을 가지고 Database처리를 해요!
        board_form = BoardForm(request.POST)  # 클라이언트가 입력한 데이터를 가지고 있는 ModelForm

        if board_form.is_valid():
            board_form.save()    # BoardForm안에 있는 데이터를 이용해서 Board class의 객체를 생성.

            # 만약 입력받은 값 이외에 테이블의 다른 컬럼의 값을 지정해서 사용하려면?
            # new_post = board_form.save(commit=False)  # 실제로 저장되지 않아요. 대신 객체를 리턴해요!
            # new_post.b_like_count = 10
            # new_post.save()

            return redirect('bbs:b_list')


def b_detail(request, board_id):
    # 게시글의 세부내용을 가져와서 화면에 출력해야 해요!
    # ModelForm을 이용해서 Database에서 가져온 내용을 화면에 출력

    # 1. board_id를 이용해서 게시글 1개를 가져와야 해요!(객체)
    post = get_object_or_404(Board, pk=board_id)
    # 2. 만들어놓은 BoardDetailForm이라는 ModelForm의 객체를
    #    위에서 만든 Board class의 객체인 post를 이용해서
    #    생성해요!
    board_detail_form = BoardDetailForm(instance=post)

    context = {
        "detail_form": board_detail_form
    }

    return render(request, 'bbs/detail.html', context)



