
from django.urls import path, include
from polls import views

# namespace 설정
app_name = "polls"

# 이 URLConf는 polls application만을 위한 URLConf 파일이예요!
# 기본적으로 URL은 http://127.0.0.1:8000/polls/

urlpatterns = [
    path('', views.index, name='index')
]
