from django.db import models


# model class를 만들때는 반드시 models.Model을 상속해야 해요!
# 모델 class를 만들 때 자동으로 PK가 하나 설정되요!
# id란 column으로 Integer타입으로 AUTO_INCREMENT형태로 생성되요!
class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField()

    def __str__(self):
        return self.question_text


class Choice(models.Model):
    choice_text = models.CharField(max_length=50)
    votes = models.IntegerField(default=0)
    question = models.ForeignKey(Question,
                                 on_delete=models.CASCADE)

    def __str__(self):
        return self.choice_text

# model class를 기반으로 명세서를 만들어야 해요!
# python manage.py makemigrations(class를 기반으로 명세서 작성)

# 실제 MySQL Database에 Table을 만들기 위해서는
# python manage.py migrate (명세서를 기준으로 실제 Table 생성)
