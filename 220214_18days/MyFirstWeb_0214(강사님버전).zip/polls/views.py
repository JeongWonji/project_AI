from django.shortcuts import render
from polls.models import Question
# Create your views here.


def index(request):
    # logic 처리
    # Database처리
    # HTML에 표현해야할 처리된 결과값들이 생길 수 있어요!
    # 이 결과값들을 dictionary에 담아요!
    question_list = Question.objects.all().order_by('-pub_date')
    context = {
        "q_list": question_list
    }
    # Template을 이용해서 클라이언트에게 response를 돌려줘요!
    # render() 함수는 Template HTML을 이용해서 HttpResponse객체를 생성

    return render(request, 'polls/index.html', context)
