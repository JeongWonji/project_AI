
$(function(event) {
    $('#new_post_btn').on('click',function(event) {
        document.location.href = '/bbs/create/'
    })
})