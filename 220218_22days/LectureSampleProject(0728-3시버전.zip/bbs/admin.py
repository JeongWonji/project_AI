from django.contrib import admin
from .models import Board, Comment

admin.site.register(Board)
admin.site.register(Comment)
