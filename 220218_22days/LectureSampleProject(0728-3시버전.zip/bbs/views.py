from django.shortcuts import render, redirect
from .models import Board
from .forms import BoardForm


def b_list(request):

    posts = Board.objects.all().order_by('-id')
    return render(request, 'bbs/list.html', {
        'posts': posts
    })


def b_create(request):

    if request.method == 'POST':
        # 새글작성화면에서 새글 저장 버튼을 눌렀을 때 실행
        # 사용자가 입력한 내용으로 데이터베이스에 입력을 해야 해요!
        board_form = BoardForm(request.POST)

        if board_form.is_valid():
            new_post = board_form.save(commit=False)
            new_post.save()
            return redirect('bbs:b_list')

    else:
        # 리스트화면에서 새글 작성 버튼을 눌렀을 때 실행
        board_form = BoardForm()
        return render(request, 'bbs/create.html', {
            'board_form': board_form
        })



