from django.urls import path
from . import views

app_name = 'bbs'
# http://localhost:8000/bbs/

urlpatterns = [
    path('list/', views.b_list, name='b_list'),
    path('create/', views.b_create, name='b_create')
]
