
function new_post() {
    document.location.href = '/bbs/create/'
}

function to_list() {
    document.location.href = '/bbs/list/'
}

function delete_post() {
    // 내가 어떤 글을 삭제할지 알아야 해요! => id(글번호)
    // alert($('#post_id').text())
    let result = confirm("정말 삭제할까요?")
    if(result) {
        let queryString = "?post_id=" + $('#post_id').text()
        // "?post_id=6"
        // "?변수=값&변수=값&변수=값"
        document.location.href = '/bbs/delete/' + queryString
    }
}

function like_post() {
    let queryString = "?post_id=" + $('#post_id').text()
    document.location.href = '/bbs/like/' + queryString
}

// 댓글등록하는 AJAX
function create_comment() {
    $.ajax({
        async: true,
        url: "/bbs/createComment/",
        type: 'GET',
        data: {
            board_id: $('#post_id').text(),
            comment_author: $('#c_name').val(),
            comment_content: $('#c_content').val()
        },
        dataType: 'json',   // 서버프로그램이 결과로 돌려주는 값은 JSON
        timeout: 3000,
        success: function(result) {
            let tr = $("<tr></tr>")
            let author_td = $('<td></td>').text(result['c_author'])
            let content_td = $('<td></td>').text(result['c_content'])
            let btn_td = $('<td></td>')
            let btn = $('<button></button>').text('삭제').addClass('btn btn-danger')
            btn_td.append(btn)
            tr.append(author_td)
            tr.append(content_td)
            tr.append(btn_td)
            $('tbody').prepend(tr)
        },
        error: function() {
            alert('먼가 이상해요!')
        }
    })
}










