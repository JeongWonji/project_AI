

module2_var = 1000