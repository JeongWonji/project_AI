
my_var = 3.141592

def my_func(a,b):
    result = a + b
    return result

class Car(object):
    def __init__(self,car_name):
        self.car_name = car_name    
    def print_name(self):
        print(self.car_name)    