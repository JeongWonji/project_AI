from django.shortcuts import render, get_object_or_404
from polls.models import Question
from django.http import HttpResponseRedirect
from django.urls import reverse


def index(request):
    # 질문객체를 모두 가져와요!
    question_list = Question.objects.all().order_by("-pub_date")

    context = {
        "q_list": question_list
    }

    # render는 HttpResponse객체를 생성하는 함수
    return render(request, "polls/index.html", context)


def detail(request, question_id):
    # 로직처리(Database처리)를 해야해요!
    #
    question = get_object_or_404(Question, pk=question_id)

    context = {
        "my_question": question
    }

    return render(request, "polls/detail.html", context)


def vote(request, question_id):
    # 질문객체를 가지고 와요!
    question = get_object_or_404(Question, pk=question_id)
    # 해당 질문객체와 ForeignKey로 연결된 객체를 가져와요!
    choice = question.choice_set.get(pk=request.POST['choice'])

    choice.votes += 1
    choice.save()

    # redirect를 사용해 보아요!
    # 클라이언트에게 응답을 주긴 주는데 그 응답의 내용이 "다른 URL에 바로
    # request를 보내" 라는 거예요!
    return HttpResponseRedirect(reverse('polls:results',
                                        args=(question.id,)))


def results(request, question_id):
    # 질문객체를 가지고 와요!
    question = get_object_or_404(Question, pk=question_id)
    context = {
        "my_question": question
    }
    return render(request, 'polls/results.html', context)
