from django.contrib import admin
from django.urls import path, include
from polls import views

app_name = 'polls'

# http://127.0.0.1:80000/polls/ 여기까지가 고정

urlpatterns = [
    # http://127.0.0.1:80000/polls/
    path('', views.index, name='index'),
    # http://127.0.0.1:80000/polls/2/
    path('<int:question_id>/', views.detail, name='detail'),
    # http://127.0.0.1:80000/polls/1/vote/
    path('<int:question_id>/vote/', views.vote, name='vote'),
    # http://127.0.0.1:80000/polls/2/results/
    path('<int:question_id>/results/', views.results, name='results'),
]
