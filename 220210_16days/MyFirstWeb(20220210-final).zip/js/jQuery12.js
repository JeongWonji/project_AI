

function my_func() {
    let my_date = $('#searchDate').val()
    if (my_date == '') {
        alert('검색을 위해 날짜를 선택해 주세요!')
    } else {
        // alert(my_date)   // 2022-02-09
        let modified_date = my_date.replace(/-/g, '')
        // alert(modified_date)
        // 우리가 필요한 날짜의 형식 => 20220209
        // AJAX 호출
        $.ajax({
            async: true,   // 동기 혹은 비동기 호출을 지정.
                           // 동기방식 : 프로그램하기가 편해요!(순차적인 처리가 가능)
                           // 비동기방식 : 효율적인데..프로그램 처리가 힘들어요(이벤트 처리방식)
            url: 'http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json',
            data: {
                key: '452ebde09792c086e5d37811e590d162',
                targetDt: modified_date
            },
            method: 'GET',
            timeout: 3000,
            dataType: 'json',
            success: function(result) {
                $('tbody').empty()
                // <tr>
                //     <td>1,001</td>    순위
                //     <td>
                //         <img src=~~~>
                //     </td>   포스터이미지
                //     <td>data</td>     영화제목
                //     <td>placeholder</td> 개봉일
                //     <td>text</td>        누적관람객수
                //     <td>
                //         <input type="button" value="삭제" class="btn btn-primary">
                //     </td>        삭제버튼
                //     <td> </td>        상세보기버튼
                // </tr>
                for(let i=0;i<10;i++) {
                    let tr = $('<tr></tr>')
                    let rankTd = $('<td></td>').text(result['boxOfficeResult']["dailyBoxOfficeList"][i]["rank"])
                    let imgTd = $('<td></td>')

                    let searchTitle = result['boxOfficeResult']["dailyBoxOfficeList"][i]["movieNm"] + " 포스터"
                    let img = $('<img />')
                    imgTd.append(img)

                    $.ajax({
                        async: true,
                        url: 'https://dapi.kakao.com/v2/search/image',
                        method: 'GET',
                        headers: {
                            Authorization: "KakaoAK " + 'c5f509547ebddb71b44b308f3ddf39ed'
                        },
                        data: {
                            query: searchTitle
                        },
                        timeout: 4000,
                        dataType: 'json',
                        success: function(result) {
                            let imgUrl = result['documents'][0]['thumbnail_url']
                            img.attr('src',imgUrl)
                        },
                        error: function() {
                            alert('먼가 이상해요!')
                        }
                    })

                    let titleTd = $('<td></td>').text(result['boxOfficeResult']["dailyBoxOfficeList"][i]["movieNm"])
                    let openTd = $('<td></td>').text(result['boxOfficeResult']["dailyBoxOfficeList"][i]["openDt"])
                    let accAudiTd = $('<td></td>').text(result['boxOfficeResult']["dailyBoxOfficeList"][i]["audiAcc"])
                    let delTd = $('<td></td>')
                    let delBtn = $('<input />').attr('type','button').attr('value','삭제')
                    // btn-primary : 파란색, btn-warning : 노란색, btn-info : 초록색, btn-danger : 빨간색
                    delBtn.addClass('btn btn-danger')
                    delBtn.on('click',function() {
                        // 현재 이벤트가 발생한 Event Source의 document Object => this
                        $(this).parent().parent().remove()
                    })
                    delTd.append(delBtn)
                    tr.append(rankTd)
                    tr.append(imgTd)
                    tr.append(titleTd)
                    tr.append(openTd)
                    tr.append(accAudiTd)
                    tr.append(delTd)
                    $('tbody').append(tr)
                }
            },
            error: function() {
                alert('먼가이상해요!!')
            }
        })
    }
}
