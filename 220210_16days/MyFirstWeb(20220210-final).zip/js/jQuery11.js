

function my_func() {
    // AJAX 호출
    $.ajax({
        async: true,   // 동기 혹은 비동기 호출을 지정.
                       // 동기방식 : 프로그램하기가 편해요!(순차적인 처리가 가능)
                       // 비동기방식 : 효율적인데..프로그램 처리가 힘들어요(이벤트 처리방식)
        url: 'http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json',
        data: {
            key: '452ebde09792c086e5d37811e590d162',
            targetDt: '20220209'
        },
        method: 'GET',
        timeout: 3000,
        dataType: 'json',
        success: function(result) {
            let m_title = result["boxOfficeResult"]["dailyBoxOfficeList"][0]["movieNm"]
            $('#myDiv').text(m_title)
        },
        error: function() {
            alert('먼가이상해요!!')
        }
    })
}