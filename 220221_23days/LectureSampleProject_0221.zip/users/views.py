from django.shortcuts import render, redirect
from django.contrib.auth import logout as django_logout, \
    login as django_login, authenticate

from users.forms import LoginForm
from django.http import HttpResponse


def login(request):
    login_form = LoginForm()
    context = {
        "my_form": login_form
    }
    return render(request, 'users/login.html', context)


def logout(request):
    # 장고가 제공해준 logout기능을 이용할 꺼예요!
    django_logout(request)
    return redirect('home')


def login_process(request):

    if request.method == 'POST':

        login_form = LoginForm(request.POST)
        username = login_form.data['username']
        password = login_form.data['password']

        # 이렇게 전달받은 username과 password를 이용해서 로그인 인증처리를 진행
        user = authenticate(username=username, password=password)

        if user is not None:
            django_login(request, user)   # 로그인 처리
            return redirect('home')
        else:
            return HttpResponse('로그인 실패. 다시 접속해 주세요!')













