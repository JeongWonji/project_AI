from django.urls import path
from users import views

# namespace설정
app_name = 'users'

# users application의 URLConf
# 여기까지의 경로는 => http://127.0.0.1:8000/users/

urlpatterns = [
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('loginProcess/', views.login_process, name='login_process'),
]
