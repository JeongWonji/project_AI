from django.urls import path
from bbs import views

# namespace설정
app_name = 'bbs'

# bbs application의 URLConf
# 여기까지의 경로는 => http://127.0.0.1:8000/bbs/

urlpatterns = [
    path('list/', views.b_list, name='b_list'),
    path('create/', views.b_create, name='b_create'),
    path('<int:board_id>/detail/', views.b_detail, name='b_detail'),
    path('delete/', views.b_delete, name='b_delete'),
    path('like/', views.b_like, name='b_like'),
    path('createComment/', views.create_comment, name='create_comment'),
    path('commentDelete/', views.delete_comment, name='delete_comment'),
]
